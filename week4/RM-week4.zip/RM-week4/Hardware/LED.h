#ifndef __LED_H
#define __LED_H

void LED_Init(void);//LED初始化
void LED_Turn(void);//LED反转

#endif
