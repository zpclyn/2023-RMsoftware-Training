#include "stm32f10x.h"                  // Device header

void LED_Init(void)//LED初始化
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);//开启时钟（GPIOC）

	GPIO_InitTypeDef GPIO_InitStructure;//配置GPIO（配置参数）
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;//配置为推挽输出
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_13;//配置GPIOC_13
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
}

void LED_Turn(void)//LED反转
{
	if(GPIO_ReadOutputDataBit(GPIOC,GPIO_Pin_13)==0)
		GPIO_SetBits(GPIOC,GPIO_Pin_13);
	else
		GPIO_ResetBits(GPIOC,GPIO_Pin_13);
}
