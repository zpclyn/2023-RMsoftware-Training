#include "stm32f10x.h"                  // Device header
#include "LED.h"

void KeyInterrupt_Init(void)//Key中断初始化
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);//开启时钟（GPIOA和AFIO）
	
	GPIO_InitTypeDef GPIO_InitStructure;//配置GPIO（配置参数）
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPD;//配置为下拉输入
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;//配置GPIOA_1
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);//初始化GPIOA
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource1);//配置AFIO（选择外部中断源和外设中断线为GPIOA_1）
	
	EXTI_InitTypeDef EXTI_InitStructure;//配置EXTI（配置参数）
	EXTI_InitStructure.EXTI_Line=EXTI_Line1;//配置中断线1
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;//使能中断线
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;//配置为外部中断模式
	EXTI_InitStructure.EXTI_Trigger=EXTI_Trigger_Rising;//选择上升沿触发
	EXTI_Init(&EXTI_InitStructure);//初始化EXTI
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//选择NVIC分组为2
	
	NVIC_InitTypeDef NVIC_InitStructure;//配置NVIC（配置参数）
	NVIC_InitStructure.NVIC_IRQChannel=EXTI1_IRQn;//配置NVIC通道1
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;//使能NVIC通道
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;//Key的抢占优先级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=2;//Key的响应优先级
	NVIC_Init(&NVIC_InitStructure);//初始化NVIC
}

void EXTI1_IRQHandler(void)//Key中断函数
{
	if(EXTI_GetITStatus(EXTI_Line1)==SET)//检测Key中断触发（即检测EXTI通道1中断触发）
	{
		EXTI_ClearITPendingBit(EXTI_Line1);//清除标志位
		LED_Turn();
	}
}
