#ifndef __INTERRUPT_H
#define __INTERRUPT_H

void KeyInterrupt_Init(void);//按键中断初始化

#endif
