#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
#include "Interrupt.h"

int main(void)
{
	LED_Init();
	KeyInterrupt_Init();
	while(1)
	{
	}
}
